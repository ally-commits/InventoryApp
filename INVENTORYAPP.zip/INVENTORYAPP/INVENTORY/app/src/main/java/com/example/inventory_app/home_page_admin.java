package com.example.inventory_app;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class home_page_admin extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_page_admin);
    }
}